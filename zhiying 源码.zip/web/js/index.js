$(document).ready(function() {

    //轮播1-大图轮播
    // var swiper = new Swiper('#indexBanner', {
    //     loop: true,
    //     effect: 'slide',
    //     //autoplay: {
    //     //  delay: 3000,
    //     //  disableOnInteraction: false,
    //     //},
    //     pagination: {
    //         el: '.swiper-pagination',
    //     },
    //     navigation: {
    //         nextEl: '.swiper-button-next',
    //         prevEl: '.swiper-button-prev',
    //     },
    // });

    //轮播2-热门电影
    // var swiper2 = new Swiper('#indexBanner2', {
    //     loop: true,
    //     effect: 'slide',
    //     //autoplay: {
    //     //  delay: 3000,
    //     //  disableOnInteraction: false,
    //     //},
    //     pagination: {
    //         el: '.swiper-pagination',
    //     },
    //     navigation: {
    //         nextEl: '.swiper-button-next',
    //         prevEl: '.swiper-button-prev',
    //     },
    // });


})