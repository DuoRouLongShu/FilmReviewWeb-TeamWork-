package com.FilmReviewWeb.Dao;


import com.FilmReviewWeb.Model.Film;
import com.FilmReviewWeb.Model.Slideshow;
import com.FilmReviewWeb.Model.User;
import com.FilmReviewWeb.Utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SlideshowDao {

    private Connection connection;
    private PreparedStatement preparedStatement;
    /**
     * 查询所有
     * @return
     */
    public List<Slideshow> findAll() throws SQLException {
        connection = JDBCUtils.getConnection();
        List<Slideshow> slideshows = new ArrayList<>();
        String sql = "select * from slideshow";
        preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet =  preparedStatement.executeQuery();
        while(resultSet.next()){
            Slideshow slideshow = new Slideshow();
            slideshow.setId(resultSet.getInt("id"));
            slideshow.setImageSource(resultSet.getString("img_src"));
            slideshows.add(slideshow);
        }


        JDBCUtils.close(connection,preparedStatement,resultSet);
        return slideshows;
    }

    public boolean saveSlideshowByFilmId(Integer filmId) throws SQLException{
        FilmDao filmDao = new FilmDao();
        Film film;
        try {
            film = filmDao.getFilmDataByFilmId(filmId);
        } catch (Exception e) {
            return false;
        }

        Slideshow slideshow = new Slideshow();
        slideshow.setId(filmId);
        slideshow.setImageSource(film.getImageSource());
        boolean hasInsert = true;
        connection = JDBCUtils.getConnection();
        String sql = "insert slideshow " +
                "(id, img_src)" +
                "values (?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1,slideshow.getId());
        preparedStatement.setString(2,slideshow.getImageSource());
        //数据库更新的条数
        int i = preparedStatement.executeUpdate();
        if (i == 0){
            hasInsert = false;
        }
        JDBCUtils.close(connection,preparedStatement);
        return hasInsert;

    }
}
