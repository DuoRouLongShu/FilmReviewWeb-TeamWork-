package com.FilmReviewWeb.Dao;


import com.FilmReviewWeb.Model.DisplayFilms;
import com.FilmReviewWeb.Model.Film;
import com.FilmReviewWeb.Model.Slideshow;
import com.FilmReviewWeb.Utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GetDetailsDao {
    private Connection connection;
    private PreparedStatement preparedStatement;
    /**
     * 根据cid查询总记录数
     */
    public int findTotalCount(int cid) throws SQLException {
        Connection connection = JDBCUtils.getConnection();
        String sql = "select count(*) from display_films where cid = ?";
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1,cid);
        ResultSet resultSet =  preparedStatement.executeQuery();
        int i = 0;
        while(resultSet.next()){
            i = resultSet.getInt(1);

        }
        JDBCUtils.close(connection,preparedStatement,resultSet);
        return i;
    }

    /**
     * 根据cid, start, pageSize查询当前页的数据集合
     */
    public List<DisplayFilms> findByPage(int cid, int start, int pageSize) throws SQLException {
        connection = JDBCUtils.getConnection();
        String sql = "select * from display_films where cid = ? limit ?, ?";
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1,cid);
        preparedStatement.setInt(2,start);
        preparedStatement.setInt(3,pageSize);
        ResultSet resultSet =  preparedStatement.executeQuery();
        List<DisplayFilms> displayFilmsList= new ArrayList<DisplayFilms>();

        while(resultSet.next()){
            DisplayFilms displayFilms = new DisplayFilms();
            displayFilms.setFilmId(resultSet.getInt("film_id"));
            displayFilms.setCid(resultSet.getInt("cid"));
            displayFilms.setFilmName(resultSet.getString("film_name"));
            displayFilms.setImageSource(resultSet.getString("img_src"));
            displayFilms.setRating(resultSet.getFloat("rating"));
            displayFilmsList.add(displayFilms);
        }

        JDBCUtils.close(connection,preparedStatement,resultSet);
        return displayFilmsList;
    };

    public boolean saveHotFilmDetailsByFilmId(Integer filmId) throws SQLException{
        FilmDao filmDao = new FilmDao();
        Film film;
        try {
            film = filmDao.getFilmDataByFilmId(filmId);
        } catch (Exception e) {
            return false;
        }

        DisplayFilms displayFilms = new DisplayFilms();
        displayFilms.setFilmId(filmId);
        displayFilms.setRating(film.getRating());
        displayFilms.setImageSource(film.getImageSource());
        displayFilms.setFilmName(film.getFilmName());
        displayFilms.setCid(1);
        boolean hasInsert = true;
        connection = JDBCUtils.getConnection();
        String sql = "insert display_films" +
                "(film_id, film_name,img_src,cid,rating)" +
                "values (?,?,?,?,?)";
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1,displayFilms.getFilmId());
        preparedStatement.setString(2,displayFilms.getFilmName());
        preparedStatement.setString(3,displayFilms.getImageSource());
        preparedStatement.setInt(4,displayFilms.getCid());
        preparedStatement.setFloat(5,displayFilms.getRating());

        //数据库更新的条数
        int i = preparedStatement.executeUpdate();
        if (i == 0){
            hasInsert = false;
        }
        JDBCUtils.close(connection,preparedStatement);
        return hasInsert;
    }
}
