package com.FilmReviewWeb.Service.Impl;


import com.FilmReviewWeb.Dao.UserDao;
import com.FilmReviewWeb.Model.User;
import com.FilmReviewWeb.Service.UserService;

import java.sql.SQLException;

public class UserServiceImpl implements UserService {

    private UserDao userDao = new UserDao();

    /**
     * 注册用户
     * @param user
     * @return
     */
    @Override
    public boolean regist(User user) throws SQLException {
        //1.根据用户名查询用户对象
        User u = userDao.findByUsername(user.getUserName());
        //判断u是否为null
        if(u != null){
            //用户名存在，注册失败
            return false;
        }
        //2.保存用户信息
        System.out.println("registService:"+user);
        userDao.save(user);
        return true;
    }

    /**
     * 登录
     * @param user
     * @return
     */
    @Override
    public User login(User user) throws SQLException {
        return userDao.findByUsernameAndPassword(user.getUserName(), user.getPassword());
    }
}
