package com.FilmReviewWeb.Servlet.AdminPage;

import com.FilmReviewWeb.Model.Result;
import com.FilmReviewWeb.Service.AdminPageService;
import com.FilmReviewWeb.Service.Impl.AdminPageServiceImpl;
import com.alibaba.fastjson.JSON;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/adminPage/addDetails")
public class addDetailsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");//告诉输出流
        resp.setContentType("text/html;charset=UTF-8");//告诉浏览器
        Result result = new Result();
        String filmId = req.getParameter("filmId");
        if(filmId == null){
            result.setMessage("未添加电影ID");
            result.setData(0);
            resp.getWriter().print(JSON.toJSONString(result));
        }
        try {
            AdminPageService adminPageService = new AdminPageServiceImpl();
            boolean hasAdd = adminPageService.addHotFilmById(Integer.parseInt(filmId));
            if(hasAdd == true){
                result.setData(true);
                result.setMessage("添加热门电影成功");
            }else {
                result.setData(false);
                result.setMessage("添加热门电影失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        resp.getWriter().print(JSON.toJSONString(result));

    }
}
