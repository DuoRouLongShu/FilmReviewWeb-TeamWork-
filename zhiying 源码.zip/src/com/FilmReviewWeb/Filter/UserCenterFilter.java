package com.FilmReviewWeb.Filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 普通用户中心鉴权过滤器
 * @author HTwo2O
 * @date 2020/5/24 21:12
 */
@WebFilter(urlPatterns = {"/personal.html","/information/*"})
public class UserCenterFilter implements Filter {
    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws ServletException, IOException {
        HttpServletResponse resp = (HttpServletResponse) response;
        HttpServletRequest req = (HttpServletRequest) request;
        Object power = req.getSession().getAttribute("power");
        if(power == null || (Integer)power != 0){
            resp.sendRedirect("./Login.html");
        }else {
            chain.doFilter(request,response);
        }
    }

    @Override
    public void init(FilterConfig config) throws ServletException {

    }

}
